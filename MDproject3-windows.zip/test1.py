import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pymysql
from pandas import DataFrame
from datetime import datetime

plt.style.use('ggplot')


class Mdproject3:
    def __init__(self):
        self.conn = pymysql.connect(host='skuser55-instance.c1aoapfinmy7.us-east-1.rds.amazonaws.com',
                                    port=3306,
                                    user='admin',
                                    password='y1syitq0is',
                                    db='mydb_test')
        self.cursor = self.connectdb.cursor()
        # self.cursor.close()
        # self.connectdb.close()

    def newtime(self, x):
        return x.strftime('%Y-%m-%d %H:%M:%S')

    def time_day(self, x):
        return x.split(' ')[0].split("-")[2]

    def save_data(self):
        show_db = '''SELECT * FROM my_topic_foreign_table'''
        self.cursor.execute(show_db)
        data = self.cursor.fetchall()

        pddata = pd.DataFrame(data, columns=["stock_name,stock_date,foreign_trading_volume,foreign_rate,create_at"])
        pddata["create_at"] = pddata["create_at"].map(lambda x: self.newtime(x))
        pddata["time_hour"] = pddata["create_at"].map(lambda x: self.time_day(x))
        return pddata

    def plt_show(self):
        pddata = self.save_data()
        plt_index = range(len(pddata[:5]))
        fig = plt.figure()
        ax1 = fig.add_subplot(1, 1, 1)

        ax1.bar(plt_index, pddata['foreign_trading_volume'][:5],align='center', color='darkblue')
        plt.xticks(plt_index, pddata['time_day'][:5], rotation=45, fontsize='large')
        ax1.xaxis.set_ticks_position('bottom')
        ax1.yaxis.set_ticks_position('left')
        ax1.set_title('foreign_stock')
        plt.xlabel('day')
        plt.ylabel('volume')
        plt.show()